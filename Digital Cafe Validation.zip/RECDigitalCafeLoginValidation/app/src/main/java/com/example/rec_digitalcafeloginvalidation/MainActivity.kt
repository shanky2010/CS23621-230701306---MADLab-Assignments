package com.example.rec_digitalcafeloginvalidation
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var validateBtn: Button

    private val passwordRegex = Regex(
        "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#\$%^&+=!]).{12,}$"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailInput = findViewById(R.id.etEmail)
        passwordInput = findViewById(R.id.etPassword)
        validateBtn = findViewById(R.id.btnValidate)

        validateBtn.setOnClickListener {
            checkCredentials()
        }
    }

    private fun checkCredentials() {

        val mailText = emailInput.text.toString().trim()
        val passText = passwordInput.text.toString().trim()

        when {

            mailText.isBlank() || passText.isBlank() -> {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            }

            !Patterns.EMAIL_ADDRESS.matcher(mailText).matches()
                    || !mailText.endsWith("@rajalakshmi.edu.in") -> {

                emailInput.error = "Enter valid college email"
                emailInput.requestFocus()
            }

            !passwordRegex.matches(passText) -> {

                passwordInput.error =
                    "Min 12 chars, 1 uppercase, 1 number & 1 special symbol"
                passwordInput.requestFocus()
            }

            else -> {
                Toast.makeText(this, "Login Validated Successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }
}