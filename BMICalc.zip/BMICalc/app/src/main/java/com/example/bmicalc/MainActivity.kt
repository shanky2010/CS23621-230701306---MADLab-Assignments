package com.example.bmicalc

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var weightBox: EditText
    private lateinit var heightBox: EditText
    private lateinit var calcButton: Button
    private lateinit var resultView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weightBox = findViewById(R.id.weightBox)
        heightBox = findViewById(R.id.heightBox)
        calcButton = findViewById(R.id.calcButton)
        resultView = findViewById(R.id.resultView)

        calcButton.setOnClickListener {
            performBMI()
        }
    }

    private fun performBMI() {

        val weightText = weightBox.text.toString()
        val heightText = heightBox.text.toString()

        when {
            weightText.isBlank() || heightText.isBlank() -> {
                Toast.makeText(this, "Enter both values", Toast.LENGTH_SHORT).show()
            }

            else -> {
                val weight = weightText.toDouble()
                val height = heightText.toDouble()

                val bmiValue = computeBMI(weight, height)

                resultView.text = "BMI Value : %.2f".format(bmiValue)
            }
        }
    }

    private fun computeBMI(w: Double, h: Double): Double {
        return w / (h * h)
    }
}