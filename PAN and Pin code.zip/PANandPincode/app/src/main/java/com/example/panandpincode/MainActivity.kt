package com.example.panandpincode
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var panInput: EditText
    private lateinit var pincodeInput: EditText
    private lateinit var validateButton: Button

    // PAN: Alphanumeric exactly 10 characters
    private val panPattern = Regex("^[A-Za-z0-9]{10}$")

    // Pincode: Exactly 6 digits
    private val pincodePattern = Regex("^\\d{6}$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        panInput = findViewById(R.id.etPan)
        pincodeInput = findViewById(R.id.etPincode)
        validateButton = findViewById(R.id.btnValidate)

        validateButton.setOnClickListener {
            validateDetails()
        }
    }

    private fun validateDetails() {

        val pan = panInput.text.toString().trim()
        val pincode = pincodeInput.text.toString().trim()

        // i) Check empty fields
        if (pan.isEmpty() || pincode.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        // ii) PAN validation (10 alphanumeric characters)
        if (!panPattern.matches(pan)) {
            panInput.error = "PAN must be exactly 10 alphanumeric characters"
            panInput.requestFocus()
            return
        }

        // iii) Pincode validation (6 digits only)
        if (!pincodePattern.matches(pincode)) {
            pincodeInput.error = "Pincode must be exactly 6 digits"
            pincodeInput.requestFocus()
            return
        }

        Toast.makeText(this, "Validation Successful", Toast.LENGTH_SHORT).show()
    }
}